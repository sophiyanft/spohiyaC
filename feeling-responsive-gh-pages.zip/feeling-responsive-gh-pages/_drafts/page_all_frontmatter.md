---
layout: page
#
# Content
#
subheadline: ""
title: ""
teaser: ""
categories:
  - 
tags:
  - 
#
# Styling
#
header: no
header:
    image_fullwidth:
    image:
    pattern:
    color:
    background-color: "#fabb00"   # You must use ""
    title:
    caption:
    caption_url:
image:
    title:
    homepage:
    thumb:
    caption:
    caption_url:
style:                      # Adding additional CSS-styles to <head>
iframe: ''
video:
    embedURL: ''
    contentURL: ''
    thumbnailUrl: ''
#
# Metainformation & Customization
#
sidebar: left
comments: true
breadcrumb: true
show_meta: false
meta_title:             # SEO: Overwrites title in <head> if needed
meta_description:
permalink:
tawkto: true               # Enable tawk.to-Service › More › _config.yml
callforaction:
  url: 
  text: 
  style: alert
#
# This is a nasty hack to make the navigation highlight
# this page as active in the topbar navigation
#
homepage: false
---

